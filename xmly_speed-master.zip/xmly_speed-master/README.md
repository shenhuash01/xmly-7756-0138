# xmly_speed
喜马拉雅极速版
[参考](https://github.com/Zero-S1/xmly_speed/blob/master/xmly_speed.md)      
暂时存档
